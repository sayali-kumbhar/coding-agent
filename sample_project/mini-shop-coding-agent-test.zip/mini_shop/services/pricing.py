def calculate_total(price: float, quantity: int) -> float:
    return price * quantity


def apply_discount(total: float, percent: float) -> float:
    return total - (total * percent / 100)
