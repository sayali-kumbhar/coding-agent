from services.pricing import calculate_total


def checkout(price: float, quantity: int) -> float:
    return calculate_total(price, quantity)
