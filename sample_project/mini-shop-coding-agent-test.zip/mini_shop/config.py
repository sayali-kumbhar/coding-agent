APP_NAME = "Mini Shop"
VERSION = "1.0"
