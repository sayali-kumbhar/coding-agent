from app import checkout


def test_checkout():
    assert checkout(50, 4) == 200
