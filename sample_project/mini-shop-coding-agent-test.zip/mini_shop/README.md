# Mini Shop

Small multi-file Python project for testing an AI coding agent.

Structure:
- app.py: application entry point
- services/pricing.py: pricing logic
- tests/: pytest tests
- config.py: configuration
